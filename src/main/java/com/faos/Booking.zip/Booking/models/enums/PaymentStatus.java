package com.faos.Booking.models.enums;

public enum PaymentStatus {
    PENDING, PAID, FAILED
}
