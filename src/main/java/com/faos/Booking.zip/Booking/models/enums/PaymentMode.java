package com.faos.Booking.models.enums;

public enum PaymentMode {
    CASH, CREDIT_CARD, DEBIT_CARD, UPI, NET_BANKING
}
