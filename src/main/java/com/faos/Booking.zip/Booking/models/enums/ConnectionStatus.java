package com.faos.Booking.models.enums;

public enum ConnectionStatus {
    ACTIVE,
    INACTIVE
}
