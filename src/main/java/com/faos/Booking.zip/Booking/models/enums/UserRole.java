package com.faos.Booking.models.enums;

public enum UserRole {
    CUSTOMER,  // Normal users who book cylinders
    ADMIN      // Admin users who manage orders
}
