package com.faos.Booking.models.enums;

public enum BookingStatus {
    PENDING,
    CONFIRMED,
    CANCELLED,
    DELIVERED
}
