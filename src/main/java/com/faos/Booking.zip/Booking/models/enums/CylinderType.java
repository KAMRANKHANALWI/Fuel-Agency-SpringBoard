package com.faos.Booking.models.enums;

public enum CylinderType {
    DOMESTIC,
    COMMERCIAL,
    INDUSTRIAL,
    AUTO_LPG
}
