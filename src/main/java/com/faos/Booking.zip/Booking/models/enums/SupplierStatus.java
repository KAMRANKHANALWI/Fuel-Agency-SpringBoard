package com.faos.Booking.models.enums;

public enum SupplierStatus {
    ACTIVE,
    INACTIVE
}
